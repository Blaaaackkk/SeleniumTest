import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class loginExample{
	private WebDriver driver;
	By userName = By.name("uid");
	By userPassword = By.name("passw");
	By title = By.cssSelector(".fl > h1:nth-child(1)");
	By submit = By.name("btnSubmit");
	
	public loginExample(WebDriver driver) {
		this.driver = driver;
	}
	
	public void setUserName(String UserName) {
		driver.findElement(userName).sendKeys(UserName);
	}
	
	public void setPassword(String Password) {
		driver.findElement(userPassword).sendKeys(Password);
	}
	
	public void submit() {
		driver.findElement(submit).click();
	}
	
	public String getSubmitTitle() {
		return driver.findElement(title).getText();
	}

	
}
