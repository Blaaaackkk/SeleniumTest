import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class homePage {
	private WebDriver driver;
	By title = By.cssSelector("#_ctl0__ctl0_Content_Main_promo > table:nth-child(1) > tbody:nth-child(1) > tr:nth-child(1) > td:nth-child(1) > h2:nth-child(1)");
	
	public homePage(WebDriver driver) {
		this.driver = driver;
	}
	
	public String getHomePageTitle() {
		return driver.findElement(title).getText();
	}

}