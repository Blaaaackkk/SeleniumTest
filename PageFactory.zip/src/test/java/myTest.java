import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class myTest {
	
	private WebDriver driver ;

	@Before
	public void setUp() throws Exception {
		System.setProperty("webdriver.gecko.driver", "B:/下载软件/火狐/geckodriver.exe");
		driver = new FirefoxDriver();
		driver.get("http://www.testfire.net/login.jsp");
	}

	@Test
	public void submitTest() {
		loginExample obSubmit = new loginExample(driver);
		String SubmitTitle = obSubmit.getSubmitTitle();
		Assert.assertTrue(SubmitTitle.contains("Online Banking Login"));
		obSubmit.setUserName("admin");
		obSubmit.setPassword("admin");
		obSubmit.submit();
		homePage homePageTitle = new homePage(driver);
		Assert.assertTrue(homePageTitle.getHomePageTitle().contains("Congratulations!"));
		
	}

}